var express = require('express');
const db = require('../database/db_connect');
var router = express.Router();
const jwt = require('../modules/jwt');
const shell = require('shelljs');
const path = require("path");

const { FileSystemWallet, Gateway } = require('fabric-network');
const ccpPath = path.resolve('/home/user/fabric-samples', '..', '..', 'basic-network', 'connection.json');
const ccpJSON = fs.read.readFileSync(ccpPath, 'utf8');
const ccp = JSON.parse(ccpJSON);


router.post("/", function(req, res, next){

  shell.cd('~');
  if(shell.exec('ls -al').code !== 0){
    shell.echo('error: command failed');
    shell.exist(1);
  }

  res.status(200).json({
    "result": false,
    "message": "error"
  });

});

router.post('/auth/ca/admin/login', function(req, res, next) {

  db.query('select * from account', async function (err, rows, field) {
    if (!err) {
      console.log(req.body.id);
      if ((req.body.id === rows[0].id) && (req.body.pw === rows[0].pw)) {
        const token = await jwt.sign(1);

        console.log("token : " + token);

        res.status(200).json({
          "result": true,
          "token" : token
        });
      } else {
        res.status(200).json({
          "result": false,
          "message": "not match"
        });
      }
      // console.log(rows[0].id);

    } else {
      console.log('err : ' + err);
      res.status(200).json({
        "result": false,
        "message": "error"
      });
    }

  })

});

router.get('/auth/ca/admin/logout', async function(req, res, next) {

  let token = req.headers.token;

  console.log(token);

  res.status(200).json({
    "result" : true,
  });

});


router.get('/check', async function(req, res, next) {

  let token = req.headers.token;

  console.log(token);

  const result = await jwt.verify(token);

  console.log(result);

  res.status(200).json({
    "result" : true,
  });

});

router.get('/query', async function(req, res, next) {

  const walletPath = path.join(process.cwd(), 'wallet');
  const wallet = new FileSystemWallet(walletPath);
  console.log(`wallet path : ${walletPath}`);

  const userExists = await wallet.exists('user1');
  if(!userExists){
    console.log("not exist user1");
    res.status(200).json({
      "result" : false,
      "message" : "not exist user1"
    });
  }

  const gateway = new Gateway();
  await gateway.connect(ccp, {wallet, identify: 'user1', discovery: {enabled: false}});

  const network = await gateway.getNetwork('mychannel');

  const contract = network.getContract('fabcar');

  const result = await contract.evaluateTransaction('queryAllCars');


  res.status(200).json({
    "result" : true,
    "message" : "not exist user1",
    "data" : result
  });


  res.status(200).json({
    "result" : true,
  });

});


module.exports = router;
